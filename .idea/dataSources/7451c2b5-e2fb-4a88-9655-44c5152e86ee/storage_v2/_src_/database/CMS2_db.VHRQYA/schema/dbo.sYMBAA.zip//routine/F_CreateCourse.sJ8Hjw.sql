
CREATE PROC dbo.F_CreateCourse (
	@CourseName NVARCHAR(30),		--新课程的名称
	@ClassName NVARCHAR(30),		--新课程的上课班级
	@Week	TINYINT,				--新课程的上课星期数
	@ClassWeek INTEGER,				--新课程的上课周次
	@ClassTime INTEGER,				--新课程的上课节次
	@Teacher NVARCHAR(20),			--新课程的任课老师
	@RID SMALLINT,					--新课程的上课课室的名称
	@StuCount INTEGER = 0,			--新课程的学生数量
	@CurTermID TINYINT = 0			--新课程所属的学期的ID
) AS BEGIN
	SET NOCOUNT ON

	IF (@Week NOT BETWEEN 0 AND 6) BEGIN
		RAISERROR(N'星期数的值应为0~6',16,1);
		RETURN;
	END

	
	IF NOT EXISTS(SELECT *FROM dbo.RoomInfo WHERE RID=@RID) BEGIN
		RAISERROR(N'课室信息没有找到,请先创建课室',16,1);
		RETURN;
	END

	IF (@StuCount=0) BEGIN
		SELECT @StuCount=RMaxCount FROM dbo.RoomInfo WHERE RID=@RID
	END
	IF (@ClassWeek=0) BEGIN
		RAISERROR(N'上课周次不能为0',16,1);
		RETURN
	END

	IF (@ClassTime=0) BEGIN
		RAISERROR(N'上课节次不能为0',16,1);
		RETURN
	END
	IF (@CurTermID=0)
		SELECT @CurTermID=1
	ELSE BEGIN
		IF NOT EXISTS(SELECT * FROM dbo.TermInfo WHERE TID=@CurTermID) BEGIN
			RAISERROR(N'找不到指定的学期',16,1);
			RETURN
		END
	END
	DECLARE @Conflict NVARCHAR(30)
	SELECT TOP 1 @Conflict=CName FROM dbo.CourseInfo WHERE TID=@CurTermID AND RID=@RID AND CWeek=@Week AND ((CClWeek&@ClassWeek)<>0 AND (CClTime&@ClassTime)<>0)
	IF @Conflict IS NULL BEGIN
		INSERT dbo.CourseInfo(TID,RID,CName,CClass,CTeacher,CWeek,CClWeek,CClTime,CStuCount) VALUES(
			@CurTermID,
		    @RID,    -- RID - smallint
			@CourseName,
		    @ClassName,  -- CClass - nvarchar(30)
		    @Teacher,  -- CTeacher - nvarchar(20)
		    @Week,    -- CWeek - tinyint
		    @ClassWeek, -- CClWeek - integer
		    @ClassTime, -- CClTime - integer
		    @StuCount     -- CStuCount - smallint
		    )
		SELECT @@IDENTITY AS New_ID
		END
	ELSE BEGIN
		SELECT @Conflict='新加入的课程与已有的课程['+LTRIM(@Conflict)+']冲突.'
		RAISERROR(@Conflict,16,1);
		RETURN;
	END


END
GO

