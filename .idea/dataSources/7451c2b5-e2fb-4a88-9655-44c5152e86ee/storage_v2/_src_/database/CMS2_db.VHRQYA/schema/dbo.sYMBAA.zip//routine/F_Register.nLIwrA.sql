
CREATE PROC dbo.F_Register(
	@UserName NVARCHAR(20),				--新注册的用户的名称
	@PassWord NVARCHAR(32),				--新注册的用户的密码的MD5
	@Name NVARCHAR(20)=NULL,			--新注册的用户的真实姓名
	@EMail NVARCHAR(50)=NULL,			--新注册的用户的邮箱,用于找回密码
	@ClassName	NVARCHAR(50)=NULL,		--新注册的用户的所属班级
	@TelPhone	NVARCHAR(20)=NULL,		--新竹的的用户的手机号码
	@Sex		BIT=1					--新注册用户的性别(1代表男,0代表女)
) AS BEGIN
	SET NOCOUNT ON

	IF @UserName IS NULL OR @UserName=N'' BEGIN
		RAISERROR(N'用户名不能为空',16,1);
		RETURN;
	END

	IF @PassWord IS NULL OR @PassWord=N'' BEGIN
		RAISERROR(N'用户密码不能为空',16,1);
		RETURN;
	END

	IF EXISTS(SELECT *FROM dbo.PersonInfo WHERE PUserName=@UserName) BEGIN
		RAISERROR(N'已经存在此用户名',16,1);
		RETURN;
	END
	INSERT dbo.PersonInfo(PUserName,PPassWord,PCtrlLevel,PEmail,PName,PTel,PClass,PSex)VALUES(
		@UserName, -- PUserName - nvarchar(50)
	    @PassWord, -- PPassWord - nvarchar(30)
	    0,   -- PCtrlLevel - tinyint
	    @EMail, -- PEmail - nvarchar(50)
	    @Name, -- PName - nvarchar(20)
	    @TelPhone, -- PTel - nvarchar(20)
	    @ClassName,  -- PClass - nvarchar(50)
		@Sex
	    )
END
GO

