--查找指定时间内有课的课室
CREATE PROC dbo.F_FilterRoom (
	@FindUsing BIT=1,					--1.查找指定时间段内被占用的课室  0.查找指定时间内空闲的课室
	@Week TINYINT=128,					--查找的星期数(从0开始编号,0为星期一),默认为显示所有的星期
	@ClassWeek INTEGER=1048575,			--查找的周次的bitmap
	@ClassTime SMALLINT=32767,			--查找的节次的bitmap
	@TermID TINYINT=0,					--查找的学期的ID
	@BuildingName NVARCHAR(20)=N'%'		--查找的建筑的名称,默认为查找全部
) AS BEGIN
	SET NOCOUNT ON
	IF (@TermID=0)
		SELECT @TermID=CONVERT(INT,GValue) FROM dbo.GlobalInfo WHERE GName=N'CurTermID'
	ELSE BEGIN
		IF NOT EXISTS(SELECT * FROM dbo.TermInfo WHERE TID=@TermID) BEGIN
			RAISERROR(N'找不到指定的学期',16,1);
			RETURN
		END
	END
	IF (@FindUsing =1)
		SELECT DISTINCT C.RID FROM dbo.CourseInfo AS C,dbo.RoomInfo AS R,dbo.BuildingInfo AS B
			WHERE C.TID=@TermID AND (C.CWeek=@Week OR @Week=128) AND R.RID=C.RID AND R.BID=B.BID AND
				 (C.CClWeek&@ClassWeek)<>0 AND (C.CClTime&@ClassTime)<>0 AND B.BName LIKE @BuildingName
	ELSE
		SELECT DISTINCT R.RID FROM dbo.RoomInfo AS R,dbo.BuildingInfo AS B
			WHERE B.BID=R.BID AND B.BName LIKE @BuildingName AND
				NOT EXISTS(SELECT * FROM dbo.CourseInfo AS C
					WHERE C.RID=R.RID AND C.TID=@TermID AND (C.CWeek=@Week OR @Week=128) AND
						 (C.CClWeek&@ClassWeek)<>0 AND (C.CClTime&@ClassTime)<>0)
END
GO

