
CREATE PROC dbo.F_LoginUser(	--检查用户账号和密码是否正确
	@UserName NVARCHAR(20),		--要进行检查的用户名
	@Password NVARCHAR(32)		--要进行检查的用户密码(真实密码的二重MD5)
) AS BEGIN
	SET NOCOUNT ON
	DECLARE @PID SMALLINT
	DECLARE @PCtrlLevel TINYINT
	SELECT @PID=PID,@PCtrlLevel=PCtrlLevel FROM dbo.PersonInfo WHERE @UserName=PUserName AND @Password=PPassword
	IF @PID IS NULL BEGIN
		RAISERROR(N'用户名或密码错误',16,1);
		RETURN;
	END ELSE BEGIN
		SELECT @PID AS PersonID,@PCtrlLevel AS PersonCtrlLevel
	END
END
GO

