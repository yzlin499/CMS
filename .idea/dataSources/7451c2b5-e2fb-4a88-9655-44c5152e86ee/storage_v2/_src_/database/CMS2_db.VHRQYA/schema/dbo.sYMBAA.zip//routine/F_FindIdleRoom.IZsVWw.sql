--用于查找指定时段内完全空闲的课室,返回所有空闲的课室的ID
CREATE PROC dbo.F_FindIdleRoom(
	@Week TINYINT,
	@ClassWeek INTEGER,
	@ClassTime SMALLINT
) AS BEGIN
SET NOCOUNT ON
SELECT DISTINCT C1.RID FROM dbo.CourseInfo AS C1 WHERE C1.CWeek=@Week AND C1.CClWeek&@ClassWeek=0 AND C1.CClTime&@ClassTime=0
END
GO

