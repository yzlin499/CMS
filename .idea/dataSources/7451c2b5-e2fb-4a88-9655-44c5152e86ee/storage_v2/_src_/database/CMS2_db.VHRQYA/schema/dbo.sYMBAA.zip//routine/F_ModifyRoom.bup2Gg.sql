--用于创建一个新的课室,如果创建成功,则返回一个新课室的ID,如果创建失败,则抛出错误
CREATE PROC dbo.F_ModifyRoom(
	@RID		SMALLINT,			--修改的课室的ID
	@RoomName	NVARCHAR(10),		--新的课室的名称
	@BuildingName NVARCHAR(10),		--新的课室所属的教学楼
	@MaxStudentCount INTEGER,		--新的课室容量
	@UseFor NVARCHAR(20)			--新的课室用途
) AS BEGIN
SET NOCOUNT ON
DECLARE @BID TINYINT
SELECT @BID=BID FROM dbo.BuildingInfo WHERE BName=@BuildingName
IF @BID IS NULL BEGIN
	INSERT dbo.BuildingInfo(BName)VALUES(@BuildingName)
	SELECT @BID=@@IDENTITY
END
UPDATE dbo.RoomInfo SET RName=@RoomName,BID=@BID,RMaxCount=@MaxStudentCount,RUseFor=@UseFor WHERE RID=@RID

END


GO

